package po;
/** @author lxl
	 *  @version Oct 23,2015
	 *      **/
	
public class OpeningStockPO {
	//包括机构、人员、车辆、库存、银行账户信息
	
}
