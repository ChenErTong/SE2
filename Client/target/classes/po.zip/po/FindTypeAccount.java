package po;
/**
 * 进行银行账户查询时的查找方式（类型）
 * @author zsq
 * @version Oct 22,2015
 */
public enum FindTypeAccount {
	ID("账户ID"),
	NAME("账户名称"),
	MONEY("账户余额");
	public final String value;
	
	FindTypeAccount(String value){
		this.value = value;
	}
	
	
}
