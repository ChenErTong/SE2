package po.receiptpo;

/**
 * 装车单：营业厅编号、汽运编号、目的地、车辆代号、监装员、押运员，所有订单订单号
 * @author czw
 * @version Oct 23, 2015
 */
public class LoadingListPO extends ReceiptPO{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public LoadingListPO(String ID) {
		super(ID);
		// TODO Auto-generated constructor stub
	}

}
