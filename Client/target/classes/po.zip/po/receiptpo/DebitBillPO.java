package po.receiptpo;

/**
 * 收款单：收款金额
 * @author czw
 * @version Oct 23, 2015
 */
public class DebitBillPO extends ReceiptPO {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public DebitBillPO(String id) {
		super(id);
		// TODO Auto-generated constructor stub
	}

}
