package po.receiptpo;

public class InventoryImportReceiptPO extends  ReceiptPO  {
	  /** @author lxl
		 *  @version Oct 23,2015
		 *      **/
		
	private static final long serialVersionUID = 1L;
	
	//目的地
	public String destination;
	//区号
	 public int a;
	//排号
	 public int b;
	//架号
	 public int c;
	//位号
	public int d;
	
	public InventoryImportReceiptPO(String ID, String destination, int a, int b, int c, int d) {
		super(ID);
		this.destination = destination;
		this.a = a;
		this.b = b;
		this.c = c;
		this.d = d;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	public String getDestination() {
		return destination;
	}

	public int getA() {
		return a;
	}

	public int getB() {
		return b;
	}

	public int getC() {
		return c;
	}

	public int getD() {
		return d;
	}
}
