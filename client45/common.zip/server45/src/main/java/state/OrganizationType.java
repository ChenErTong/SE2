package state;

public enum OrganizationType {
	BRANCH,TRANSFER;
}
