package state;

public enum ResultMessage {
	SUCCESS,
	FAIL,
	WAIT;
}


/*public class ResultMessage {
	
	
	boolean pass;
	String message;
	
	public ResultMessage(boolean pass, String message) {
		super();
		this.pass = pass;
		this.message = message;
	}
	
}*/
