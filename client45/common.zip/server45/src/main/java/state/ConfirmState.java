package state;
/**
 * 操作确认状态
 * @author czw
 * @version Oct 22,2015
 */
public enum ConfirmState {
	CONFIRM("确认"),
	CANCEL("取消");
	
	public final String value;
	
	ConfirmState(String value){
		this.value = value;
	}
}
